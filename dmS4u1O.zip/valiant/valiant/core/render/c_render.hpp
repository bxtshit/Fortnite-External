#pragma once
#ifndef C_RENDER_HPP
#define C_RENDER_HPP

class render
{
public:
	void run( );
};

#endif