#ifndef C_RENDER_CPP
#define C_RENDER_CPP

#include "../../core/includes.hpp"

void render::run( )
{

}

#endif