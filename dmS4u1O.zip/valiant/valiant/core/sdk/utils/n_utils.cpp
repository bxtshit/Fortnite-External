#ifndef N_UTILS_CPP
#define N_UTILS_CPP

#include "../../../core/sdk/utils/n_utils.hpp"

std::pair<uintptr_t, uengine::ftransform> utils::bone::get_bone_data( uintptr_t mesh )
{
	auto bone_array = uefi->read<uintptr_t>( mesh + offsets->BoneArray + (uefi->read<int>( mesh + offsets->BoneCached ) * 0x10) );
	auto component_to_world = uefi->read<uengine::ftransform>( mesh + offsets->ComponentToWorld );

	return std::make_pair( bone_array, component_to_world );
}

uengine::ftransform utils::bone::get_bone_transform( uintptr_t bone_array, int id )
{
	return uefi->read<uengine::ftransform>( bone_array + id * 0x60 );
}

math_primitives::fvector utils::bone::process_bone_transform( uengine::ftransform bone_transform, uengine::ftransform component_to_world )
{
	auto bone_matrix = uengine::matrix_multiplication( bone_transform.to_matrix_with_scale( ), component_to_world.to_matrix_with_scale( ) );
	return math_primitives::fvector( bone_matrix._41, bone_matrix._42, bone_matrix._43 );
}

void utils::camera::setup( )
{
	const auto gworld = uefi->read<uintptr_t>( uefi->base_address + offsets->GWorld );
	const auto game_instance = uefi->read<uintptr_t>( gworld + offsets->GameInstance );
	const auto local_player = uefi->read<uintptr_t>( uefi->read<uintptr_t>( game_instance + offsets->LocalPlayers ) );
	const auto view_matrix = uefi->read<uintptr_t>( local_player + 0xd0 );

	view_state = uefi->read<uintptr_t>( view_matrix + 0x8 );
}

void utils::camera::update( )
{
	auto projection = uefi->read<uengine::fmatrix>( view_state + 0x900 );

	camera_data->rotation.pitch = asin( projection.z_plane.w ) * rad_to_deg;
	camera_data->rotation.yaw = atan2( projection.y_plane.w, projection.x_plane.w ) * rad_to_deg;
	camera_data->rotation.roll = 0.0f;

	camera_data->location.x = projection.m[ 3 ][ 0 ];
	camera_data->location.y = projection.m[ 3 ][ 1 ];
	camera_data->location.z = projection.m[ 3 ][ 2 ];

	auto fov_radians = 2.0f * atanf( 1.0f / static_cast<float>(uefi->read<double>( view_state + 0x700 )) );
	camera_data->fov = fov_radians * rad_to_deg;
}

math_primitives::fvector2d utils::screen::world_to_screen( math_primitives::fvector location, D3DMATRIX rotation_matrix, float fov_type_shit )
{
	auto& axis_x = rotation_matrix.m[ 0 ];
	auto& axis_y = rotation_matrix.m[ 1 ];
	auto& axis_z = rotation_matrix.m[ 2 ];

	math_primitives::fvector delta = location - camera_data->location;

	auto transformed_x = delta.dot( math_primitives::fvector( axis_y[ 0 ], axis_y[ 1 ], axis_y[ 2 ] ) );
	auto transformed_y = delta.dot( math_primitives::fvector( axis_z[ 0 ], axis_z[ 1 ], axis_z[ 2 ] ) );
	auto transformed_z = max( delta.dot( math_primitives::fvector( axis_x[ 0 ], axis_x[ 1 ], axis_x[ 2 ] ) ), 1.0f );

	auto screen_x = math_primitives::s_width_center + transformed_x * (math_primitives::s_width_center / fov_type_shit) / transformed_z;
	auto screen_y = math_primitives::s_height_center - transformed_y * (math_primitives::s_width_center / fov_type_shit) / transformed_z;

	return math_primitives::fvector2d( screen_x, screen_y );
}

std::string utils::weapon::get_weapon_name( uintptr_t current_weapon )
{
	auto weapon_data = uefi->read<uint64_t>( current_weapon + offsets->WeaponData );
	if ( !weapon_data ) return hash_str( "null" );

	auto fname_text = uefi->read<uint64_t>( weapon_data + offsets->ItemName );
	if ( !fname_text ) return hash_str( "null" );

	auto name_length = uefi->read<uint32_t>( fname_text + 0x30 );
	if ( !name_length ) return hash_str( "null" );

	wchar_t* name = new wchar_t[ uint64_t( name_length ) + 1 ];

	//if ( !vm->read_array( (uintptr_t)vm->read<PVOID>( fname_text + 0x28 ), (name), name_length * sizeof( wchar_t ) ) ) { log_error( ); }

	std::wstring wname( name );
	return std::string( wname.begin( ), wname.end( ) );
}

math_primitives::fvector utils::weapon::predict_location( const math_primitives::fvector& target_initial, const math_primitives::fvector& velocity, float distance )
{
	auto target = target_initial;
	auto time = distance / speed;

	target.add_scale( velocity, time );

	auto gravity1 = fabs( -980.0f * gravity ) * 0.5f * time * time;
	target.z += gravity1;

	return target;
}

bool utils::other::is_visible( uintptr_t mesh )
{
	auto submit_time = uefi->read<float>( mesh + 0x2E8 );
	auto render_time = uefi->read<float>( mesh + 0x2F0 );

	return render_time + 0.06f >= submit_time;
}

std::string utils::other::get_rank( int32_t rank_progress )
{
	if ( rank_progress == 0 )
		return std::string( hash_str( "bronze 1" ) );
	else if ( rank_progress == 1 )
		return std::string( hash_str( "bronze 2" ) );
	else if ( rank_progress == 2 )
		return std::string( hash_str( "bronze 3" ) );
	else if ( rank_progress == 3 )
		return std::string( hash_str( "silver 1" ) );
	else if ( rank_progress == 4 )
		return std::string( hash_str( "silver 2" ) );
	else if ( rank_progress == 5 )
		return std::string( hash_str( "silver 3" ) );
	else if ( rank_progress == 6 )
		return std::string( hash_str( "gold 1" ) );
	else if ( rank_progress == 7 )
		return std::string( hash_str( "gold 2" ) );
	else if ( rank_progress == 8 )
		return std::string( hash_str( "gold 3" ) );
	else if ( rank_progress == 9 )
		return std::string( hash_str( "platinum 1" ) );
	else if ( rank_progress == 10 )
		return std::string( hash_str( "platinum 2" ) );
	else if ( rank_progress == 11 )
		return std::string( hash_str( "platinum 3" ) );
	else if ( rank_progress == 12 )
		return std::string( hash_str( "diamond 1" ) );
	else if ( rank_progress == 13 )
		return std::string( hash_str( "diamond 2" ) );
	else if ( rank_progress == 14 )
		return std::string( hash_str( "diamond 3" ) );
	else if ( rank_progress == 15 )
		return std::string( hash_str( "elite" ) );
	else if ( rank_progress == 16 )
		return std::string( hash_str( "champion" ) );
	else if ( rank_progress == 17 )
		return std::string( hash_str( "unreal" ) );
	else
		return std::string( hash_str( "null" ) );
}

#endif