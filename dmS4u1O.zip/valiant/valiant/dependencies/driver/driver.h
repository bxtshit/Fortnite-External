#pragma once
#include <Windows.h>
#include <cstdint>
#include <TlHelp32.h>
#include <iostream>
#include "driver_requests.h"

class ioctl
{
public:

    HANDLE device_handle;
    INT32 process_id;
    uintptr_t base_address;

	bool setup_driver();

	bool read_physical(PVOID address, PVOID buffer, DWORD size);

	uintptr_t get_base_address();

	uintptr_t attach(LPCTSTR process_name);

	bool get_dtb();

	template <typename T>
	T read(uint64_t address)
	{
		T buffer{ };
		ioctl::read_physical((PVOID)address, &buffer, sizeof(T));
		return buffer;
	}
}; inline std::unique_ptr<ioctl> uefi = std::make_unique<ioctl>();