#pragma once

class vars
{
public:
	struct
	{
		bool enabled = false;

		int type = 0;

		float fov = 250;

		float smoothing_x = 5;
		float smoothing_y = 5;

		struct
		{
			bool dot = false;
			bool line = false;
			bool fov = false;
		} display;
	} aimbot;

	struct
	{
		bool box = false;
		bool skeleton = false;
		bool distance = false;
		bool rank = false;
		bool weapon_class = false;

		float max_distance = 300;
	} visuals;

	struct
	{
		bool vsync = false;

		struct
		{
			bool logo = false;
			bool tps = false;
		} watermark;
	} misc;
}; inline std::unique_ptr<vars> g_vars = std::make_unique<vars>( );