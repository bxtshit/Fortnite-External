#pragma once
#ifndef ENTRY_CPP
#define ENTRY_CPP

#include "core/includes.hpp"

int main( )
{
	return 0;
}

#endif